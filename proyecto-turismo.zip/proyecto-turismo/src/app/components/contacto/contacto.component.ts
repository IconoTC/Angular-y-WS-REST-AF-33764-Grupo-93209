import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  contactoForm: FormGroup = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6,7,9]{1}[0-9]{8}')]),
    email: new FormControl('', [Validators.required, Validators.email]),
    asunto: new FormControl('', [Validators.required, Validators.minLength(5)]),
    mensaje: new FormControl('', [Validators.required, Validators.minLength(10)])
  });

  constructor() { }

  guardar(): void{
    console.log(this.contactoForm.value);
  }

  ngOnInit(): void {
  }

}
