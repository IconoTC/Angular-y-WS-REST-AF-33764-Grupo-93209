import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  idioma: string = 'es';
  user: string = '';

  constructor(private translateService: TranslateService, private loginService: LoginService) { 
    translateService.setDefaultLang(this.idioma);
    loginService.comprobarLogado().subscribe(datos => {
      this.user = datos.multiFactor.user.email;
    });
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;
    this.translateService.use(this.idioma);
  }

  cerrarSesion(): void{
    this.loginService.logout()
      .then(() => {
        this.user = '';
      })
      .catch(error => {
        console.log(error)
      });
  }

  ngOnInit(): void {
  }

}
