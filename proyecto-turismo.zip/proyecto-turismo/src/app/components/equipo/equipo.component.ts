import { Component, OnInit } from '@angular/core';
import { EquipoService } from 'src/app/services/equipo.service';

@Component({
  selector: 'app-equipo',
  templateUrl: './equipo.component.html',
  styleUrls: ['./equipo.component.css']
})
export class EquipoComponent implements OnInit {

  equipo: any[] = [];

  constructor(private equipoService: EquipoService) { 
    equipoService.getAll().subscribe(datos => {
      console.log(datos);
      //this.equipo = datos.results;

      // El servicio de Harry Potter no tiene paginacion y yo solo quiero 20 personajes
      for(let i=0; i<20; i++){
        this.equipo.push(datos[i]);
      }
    });
  }

  ngOnInit(): void {
  }

}
