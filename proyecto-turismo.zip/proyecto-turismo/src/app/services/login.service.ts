import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private angularFireAuth: AngularFireAuth) { }

  login(email:string, pw:string): Promise<any>{
    return this.angularFireAuth.signInWithEmailAndPassword(email, pw);
  }

  registro(email:string, pw:string): Promise<any>{
    return this.angularFireAuth.createUserWithEmailAndPassword(email, pw);
  }

  logout(): Promise<void>{
    return this.angularFireAuth.signOut();
  }

  comprobarLogado(): Observable<any>{
    return this.angularFireAuth.authState;
  }
}
