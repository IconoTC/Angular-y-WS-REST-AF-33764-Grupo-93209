// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCmCQCbntHh0bDMf8RfQ0aR_aKtABGeazA",
    authDomain: "angular-indra-anabel-13-3-26.firebaseapp.com",
    projectId: "angular-indra-anabel-13-3-26",
    storageBucket: "angular-indra-anabel-13-3-26.firebasestorage.app",
    messagingSenderId: "731876022450",
    appId: "1:731876022450:web:ee0e55ff5093445da551ab"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
