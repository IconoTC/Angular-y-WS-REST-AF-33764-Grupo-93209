export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCmCQCbntHh0bDMf8RfQ0aR_aKtABGeazA",
    authDomain: "angular-indra-anabel-13-3-26.firebaseapp.com",
    projectId: "angular-indra-anabel-13-3-26",
    storageBucket: "angular-indra-anabel-13-3-26.firebasestorage.app",
    messagingSenderId: "731876022450",
    appId: "1:731876022450:web:ee0e55ff5093445da551ab"
  }
};
