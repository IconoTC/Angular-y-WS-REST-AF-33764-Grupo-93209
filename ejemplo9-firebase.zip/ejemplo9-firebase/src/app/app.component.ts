import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  amigos: any[] = [];
  id: string = '';
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    //id: new FormControl(0, [Validators.required, Validators.min(1)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
     agendaService.getAll().subscribe(datos => {
      console.log(datos);
      // limpiar la lista de amigos
      this.amigos = [];
      datos.forEach(item => {
        this.amigos.push(item.payload.doc.data());
      });
     });
  }

  modificar(): void{
    this.agendaService.modificarAmigo(this.id, this.amigoForm.value)
      .then(() => {
          setTimeout(() => {
            this.mostrar = false;  // ocultar el formulario
            this.contacto = null;  // ocultar el contacto encontrado
            this.id = ''; // limpiar el formulario
            this.amigoForm.reset();
            alert("Contacto modificado");
          }, 500)
      })
      .catch(error => {
        console.log(error);
      });
  }

  editar(): void{
    this.amigoForm.setValue(this.contacto);
    this.mostrar = true;
  }

  borrar(): void{
    this.agendaService.eliminarAmigo(this.id)
      .then(() => {
          this.id = '';  // Limpiar el campo del formulario
          this.contacto = null; // oculatr el contacto encontrado
          alert("Contacto eliminado");
      })
      .catch(error => {
        console.log(error);
      });
  }

  buscar(): void{
    this.agendaService.buscarAmigo(this.id).subscribe(item => {
      this.contacto = item.payload.data();
    });
  }

  alta(): void{
    console.log(this.amigoForm.value);
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then(() => {
        // limpiar el formulario
        this.amigoForm.reset();
        alert("Contacto creado");
      })
      .catch(error => {
        console.log(error);
      });
  }
}
