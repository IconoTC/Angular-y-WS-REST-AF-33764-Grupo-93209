import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private amigos: any[] = [
    {id:1, nombre:'Juan', telefono: '616111111'},
    {id:2, nombre:'Maria', telefono: '616222222'}
  ];

  constructor() { }

  getAll(): any[]{
    return this.amigos;
  }

  nuevoAmigo(nuevo: any): void{
    this.amigos.push(nuevo);
  }

  buscarAmigo(id: number): any{
    return this.amigos.find(item => item.id == id); // igualdad estricta === no funciona
  }

  modificarAmigo(amigo: any): void{
    this.amigos.forEach(item => {
      if (item.id == amigo.id){
        item.nombre = amigo.nombre;
        item.telefono = amigo.telefono;
      }
    });
  }

  eliminarAmigo(id: number): void{
    // Buscamos el indice de la lista donde se encuentra el objeto a eliminar
    let idx = this.amigos.findIndex(item => item.id == id);
    // Empieza a borrar desde el indice indicado y borra solo un objeto
    this.amigos.splice(idx, 1);
  }
}
